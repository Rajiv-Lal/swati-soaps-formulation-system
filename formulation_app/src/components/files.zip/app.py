"""
SWATI SOAPS FORMULATION MANAGEMENT SYSTEM - BACKEND API
Flask REST API with SQLAlchemy ORM
Version: 2.0 (Session 1 Enhanced)
"""

from flask import Flask, request, jsonify
from flask_cors import CORS
from flask_jwt_extended import JWTManager, create_access_token, jwt_required, get_jwt_identity
from datetime import datetime, timedelta
import sqlite3
import json
import os
from functools import wraps

app = Flask(__name__)

# Configuration
app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY', 'dev-secret-key-change-in-production')
app.config['JWT_SECRET_KEY'] = os.environ.get('JWT_SECRET_KEY', 'jwt-secret-key-change-in-production')
app.config['JWT_ACCESS_TOKEN_EXPIRES'] = timedelta(hours=24)
app.config['DATABASE'] = os.environ.get('DATABASE_PATH', 'swati_soaps.db')

# Initialize extensions
CORS(app, resources={r"/api/*": {"origins": "http://localhost:3000"}})
jwt = JWTManager(app)

# Database connection helper
def get_db():
    """Get database connection"""
    conn = sqlite3.connect(app.config['DATABASE'])
    conn.row_factory = sqlite3.Row  # Return rows as dictionaries
    return conn

def dict_from_row(row):
    """Convert sqlite3.Row to dictionary"""
    return dict(zip(row.keys(), row)) if row else None

# Error handlers
@app.errorhandler(404)
def not_found(error):
    return jsonify({'error': 'Not found'}), 404

@app.errorhandler(500)
def internal_error(error):
    return jsonify({'error': 'Internal server error'}), 500

# ============================================================================
# AUTHENTICATION ENDPOINTS
# ============================================================================

@app.route('/api/auth/login', methods=['POST'])
def login():
    """User login"""
    try:
        data = request.get_json()
        email = data.get('email')
        password = data.get('password')
        
        if not email or not password:
            return jsonify({'error': 'Email and password required'}), 400
        
        conn = get_db()
        cursor = conn.cursor()
        
        # Find user
        cursor.execute('SELECT * FROM users WHERE email = ? AND is_active = 1', (email,))
        user = cursor.fetchone()
        
        if not user:
            return jsonify({'error': 'Invalid credentials'}), 401
        
        # In production, verify password hash using bcrypt
        # For now, simple check (CHANGE IN PRODUCTION!)
        # if not bcrypt.checkpw(password.encode('utf-8'), user['password_hash'].encode('utf-8')):
        #     return jsonify({'error': 'Invalid credentials'}), 401
        
        # Update last login
        cursor.execute('UPDATE users SET last_login = ? WHERE id = ?', 
                      (datetime.now().isoformat(), user['id']))
        conn.commit()
        conn.close()
        
        # Create access token
        access_token = create_access_token(identity=user['id'])
        
        return jsonify({
            'token': access_token,
            'user': {
                'id': user['id'],
                'email': user['email'],
                'name': user['name'],
                'role': user['role']
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/auth/me', methods=['GET'])
@jwt_required()
def get_current_user():
    """Get current user info"""
    try:
        user_id = get_jwt_identity()
        
        conn = get_db()
        cursor = conn.cursor()
        cursor.execute('SELECT id, email, name, role FROM users WHERE id = ?', (user_id,))
        user = cursor.fetchone()
        conn.close()
        
        if not user:
            return jsonify({'error': 'User not found'}), 404
        
        return jsonify({'user': dict_from_row(user)}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============================================================================
# INGREDIENT ENDPOINTS
# ============================================================================

@app.route('/api/ingredients', methods=['GET'])
@jwt_required()
def get_ingredients():
    """Get all ingredients with optional filtering"""
    try:
        # Query parameters
        category_id = request.args.get('category_id')
        search = request.args.get('search')
        tag = request.args.get('tag')
        
        conn = get_db()
        cursor = conn.cursor()
        
        query = '''
            SELECT i.*, c.name as category_name, sc.name as subcategory_name,
                   s.name as supplier_name
            FROM ingredients i
            LEFT JOIN categories c ON i.category_id = c.id
            LEFT JOIN subcategories sc ON i.subcategory_id = sc.id
            LEFT JOIN suppliers s ON i.supplier_id = s.id
            WHERE 1=1
        '''
        params = []
        
        if category_id:
            query += ' AND i.category_id = ?'
            params.append(category_id)
        
        if search:
            query += ' AND (i.name LIKE ? OR i.inci_name LIKE ?)'
            search_term = f'%{search}%'
            params.extend([search_term, search_term])
        
        if tag:
            query += ''' AND i.id IN (
                SELECT ingredient_id FROM ingredient_tags WHERE tag = ?
            )'''
            params.append(tag)
        
        query += ' ORDER BY i.name'
        
        cursor.execute(query, params)
        ingredients = [dict_from_row(row) for row in cursor.fetchall()]
        conn.close()
        
        return jsonify({'ingredients': ingredients}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/ingredients/<int:id>', methods=['GET'])
@jwt_required()
def get_ingredient(id):
    """Get single ingredient"""
    try:
        conn = get_db()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT i.*, c.name as category_name, sc.name as subcategory_name,
                   s.name as supplier_name
            FROM ingredients i
            LEFT JOIN categories c ON i.category_id = c.id
            LEFT JOIN subcategories sc ON i.subcategory_id = sc.id
            LEFT JOIN suppliers s ON i.supplier_id = s.id
            WHERE i.id = ?
        ''', (id,))
        
        ingredient = cursor.fetchone()
        
        if not ingredient:
            conn.close()
            return jsonify({'error': 'Ingredient not found'}), 404
        
        # Get tags
        cursor.execute('SELECT tag FROM ingredient_tags WHERE ingredient_id = ?', (id,))
        tags = [row['tag'] for row in cursor.fetchall()]
        
        conn.close()
        
        result = dict_from_row(ingredient)
        result['tags'] = tags
        
        return jsonify({'ingredient': result}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/ingredients', methods=['POST'])
@jwt_required()
def create_ingredient():
    """Create new ingredient"""
    try:
        data = request.get_json()
        
        # Validation
        if not data.get('name'):
            return jsonify({'error': 'Ingredient name is required'}), 400
        
        conn = get_db()
        cursor = conn.cursor()
        
        # Check for duplicate name
        cursor.execute('SELECT id FROM ingredients WHERE name = ?', (data['name'],))
        if cursor.fetchone():
            conn.close()
            return jsonify({'error': 'Ingredient name already exists'}), 400
        
        # Insert ingredient
        cursor.execute('''
            INSERT INTO ingredients (
                name, category_id, subcategory_id, landed_cost_net_gst,
                stock_status, supplier_id, hsn_code, cas_number, inci_name,
                minimum_order_qty, unit_of_measure, storage_conditions,
                shelf_life_months, created_at, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            data['name'],
            data.get('category_id'),
            data.get('subcategory_id'),
            data.get('landed_cost_net_gst', 0),
            data.get('stock_status', 'in_stock'),
            data.get('supplier_id'),
            data.get('hsn_code'),
            data.get('cas_number'),
            data.get('inci_name'),
            data.get('minimum_order_qty', 1),
            data.get('unit_of_measure', 'kg'),
            data.get('storage_conditions'),
            data.get('shelf_life_months'),
            datetime.now().isoformat(),
            datetime.now().isoformat()
        ))
        
        ingredient_id = cursor.lastrowid
        
        # Add tags if provided
        tags = data.get('tags', [])
        for tag in tags:
            cursor.execute(
                'INSERT INTO ingredient_tags (ingredient_id, tag) VALUES (?, ?)',
                (ingredient_id, tag)
            )
        
        conn.commit()
        conn.close()
        
        return jsonify({
            'message': 'Ingredient created successfully',
            'ingredient_id': ingredient_id
        }), 201
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/ingredients/<int:id>', methods=['PUT'])
@jwt_required()
def update_ingredient(id):
    """Update ingredient"""
    try:
        data = request.get_json()
        
        conn = get_db()
        cursor = conn.cursor()
        
        # Check if exists
        cursor.execute('SELECT id FROM ingredients WHERE id = ?', (id,))
        if not cursor.fetchone():
            conn.close()
            return jsonify({'error': 'Ingredient not found'}), 404
        
        # Update ingredient
        cursor.execute('''
            UPDATE ingredients SET
                name = ?, category_id = ?, subcategory_id = ?,
                landed_cost_net_gst = ?, stock_status = ?, supplier_id = ?,
                hsn_code = ?, cas_number = ?, inci_name = ?,
                minimum_order_qty = ?, unit_of_measure = ?,
                storage_conditions = ?, shelf_life_months = ?,
                updated_at = ?
            WHERE id = ?
        ''', (
            data.get('name'),
            data.get('category_id'),
            data.get('subcategory_id'),
            data.get('landed_cost_net_gst'),
            data.get('stock_status'),
            data.get('supplier_id'),
            data.get('hsn_code'),
            data.get('cas_number'),
            data.get('inci_name'),
            data.get('minimum_order_qty'),
            data.get('unit_of_measure'),
            data.get('storage_conditions'),
            data.get('shelf_life_months'),
            datetime.now().isoformat(),
            id
        ))
        
        # Update tags
        if 'tags' in data:
            cursor.execute('DELETE FROM ingredient_tags WHERE ingredient_id = ?', (id,))
            for tag in data['tags']:
                cursor.execute(
                    'INSERT INTO ingredient_tags (ingredient_id, tag) VALUES (?, ?)',
                    (id, tag)
                )
        
        conn.commit()
        conn.close()
        
        return jsonify({'message': 'Ingredient updated successfully'}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/ingredients/<int:id>', methods=['DELETE'])
@jwt_required()
def delete_ingredient(id):
    """Delete ingredient"""
    try:
        conn = get_db()
        cursor = conn.cursor()
        
        # Check if ingredient is used in any formulations
        cursor.execute(
            'SELECT COUNT(*) as count FROM formulation_ingredients WHERE ingredient_id = ?',
            (id,)
        )
        count = cursor.fetchone()['count']
        
        if count > 0:
            conn.close()
            return jsonify({
                'error': f'Cannot delete. Ingredient is used in {count} formulation(s)'
            }), 400
        
        # Delete ingredient (cascade will delete tags)
        cursor.execute('DELETE FROM ingredients WHERE id = ?', (id,))
        
        if cursor.rowcount == 0:
            conn.close()
            return jsonify({'error': 'Ingredient not found'}), 404
        
        conn.commit()
        conn.close()
        
        return jsonify({'message': 'Ingredient deleted successfully'}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============================================================================
# CATEGORY ENDPOINTS
# ============================================================================

@app.route('/api/categories', methods=['GET'])
@jwt_required()
def get_categories():
    """Get all categories with subcategories"""
    try:
        conn = get_db()
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM categories ORDER BY display_order, name')
        categories = [dict_from_row(row) for row in cursor.fetchall()]
        
        # Get subcategories for each category
        for category in categories:
            cursor.execute(
                'SELECT * FROM subcategories WHERE category_id = ? ORDER BY display_order, name',
                (category['id'],)
            )
            category['subcategories'] = [dict_from_row(row) for row in cursor.fetchall()]
        
        conn.close()
        
        return jsonify({'categories': categories}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/subcategories/<int:category_id>', methods=['GET'])
@jwt_required()
def get_subcategories(category_id):
    """Get subcategories for a category"""
    try:
        conn = get_db()
        cursor = conn.cursor()
        
        cursor.execute(
            'SELECT * FROM subcategories WHERE category_id = ? ORDER BY display_order, name',
            (category_id,)
        )
        subcategories = [dict_from_row(row) for row in cursor.fetchall()]
        conn.close()
        
        return jsonify({'subcategories': subcategories}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============================================================================
# FORMULATION ENDPOINTS
# ============================================================================

@app.route('/api/formulations', methods=['GET'])
@jwt_required()
def get_formulations():
    """Get all formulations with filtering"""
    try:
        status = request.args.get('status')
        search = request.args.get('search')
        
        conn = get_db()
        cursor = conn.cursor()
        
        query = '''
            SELECT f.*, pt.name as product_type_name,
                   u.name as created_by_name,
                   COUNT(DISTINCT fi.ingredient_id) as ingredient_count
            FROM formulations f
            LEFT JOIN product_types pt ON f.product_type_id = pt.id
            LEFT JOIN users u ON f.created_by = u.id
            LEFT JOIN formulation_ingredients fi ON f.id = fi.formulation_id
            WHERE 1=1
        '''
        params = []
        
        if status:
            query += ' AND f.status = ?'
            params.append(status)
        
        if search:
            query += ' AND f.product_name LIKE ?'
            params.append(f'%{search}%')
        
        query += ' GROUP BY f.id ORDER BY f.created_at DESC'
        
        cursor.execute(query, params)
        formulations = [dict_from_row(row) for row in cursor.fetchall()]
        conn.close()
        
        return jsonify({'formulations': formulations}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/formulations/<int:id>', methods=['GET'])
@jwt_required()
def get_formulation(id):
    """Get single formulation with full details"""
    try:
        conn = get_db()
        cursor = conn.cursor()
        
        # Get formulation
        cursor.execute('''
            SELECT f.*, pt.name as product_type_name, u.name as created_by_name
            FROM formulations f
            LEFT JOIN product_types pt ON f.product_type_id = pt.id
            LEFT JOIN users u ON f.created_by = u.id
            WHERE f.id = ?
        ''', (id,))
        
        formulation = cursor.fetchone()
        
        if not formulation:
            conn.close()
            return jsonify({'error': 'Formulation not found'}), 404
        
        result = dict_from_row(formulation)
        
        # Get ingredients
        cursor.execute('''
            SELECT fi.*, i.name as ingredient_name, i.landed_cost_net_gst,
                   c.name as category_name
            FROM formulation_ingredients fi
            JOIN ingredients i ON fi.ingredient_id = i.id
            LEFT JOIN categories c ON i.category_id = c.id
            WHERE fi.formulation_id = ?
            ORDER BY fi.display_order, i.name
        ''', (id,))
        
        result['ingredients'] = [dict_from_row(row) for row in cursor.fetchall()]
        
        # Get benefits
        cursor.execute('''
            SELECT bc.id, bc.name
            FROM formulation_benefits fb
            JOIN benefit_categories bc ON fb.benefit_id = bc.id
            WHERE fb.formulation_id = ?
        ''', (id,))
        
        result['benefits'] = [dict_from_row(row) for row in cursor.fetchall()]
        
        # Get tags
        cursor.execute('''
            SELECT t.id, t.name, t.color
            FROM formulation_tags ft
            JOIN tags t ON ft.tag_id = t.id
            WHERE ft.formulation_id = ?
        ''', (id,))
        
        result['tags'] = [dict_from_row(row) for row in cursor.fetchall()]
        
        conn.close()
        
        return jsonify({'formulation': result}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/formulations', methods=['POST'])
@jwt_required()
def create_formulation():
    """Create new formulation"""
    try:
        data = request.get_json()
        user_id = get_jwt_identity()
        
        # Validation
        if not data.get('product_name'):
            return jsonify({'error': 'Product name is required'}), 400
        
        if not data.get('grammage'):
            return jsonify({'error': 'Grammage is required'}), 400
        
        ingredients = data.get('ingredients', [])
        if not ingredients:
            return jsonify({'error': 'At least one ingredient is required'}), 400
        
        # Validate percentages sum to 100
        total_percentage = sum(float(ing.get('percentage', 0)) for ing in ingredients)
        if abs(total_percentage - 100.0) > 0.01:
            return jsonify({'error': f'Percentages must sum to 100% (currently {total_percentage}%)'}), 400
        
        conn = get_db()
        cursor = conn.cursor()
        
        # Check for duplicate name
        cursor.execute('SELECT id FROM formulations WHERE product_name = ?', (data['product_name'],))
        if cursor.fetchone():
            conn.close()
            return jsonify({'error': 'Product name already exists'}), 400
        
        # Calculate total cost
        total_cost = 0
        grammage = float(data['grammage'])
        
        for ing in ingredients:
            cursor.execute(
                'SELECT landed_cost_net_gst FROM ingredients WHERE id = ?',
                (ing['ingredient_id'],)
            )
            ingredient = cursor.fetchone()
            if ingredient:
                cost_per_kg = float(ingredient['landed_cost_net_gst'])
                percentage = float(ing['percentage'])
                quantity_kg = (grammage * percentage) / 100000
                ing['cost_per_piece'] = quantity_kg * cost_per_kg
                ing['quantity_grams'] = (grammage * percentage) / 100
                total_cost += ing['cost_per_piece']
        
        # Insert formulation
        cursor.execute('''
            INSERT INTO formulations (
                product_name, product_type_id, current_version, grammage,
                pack_count, status, total_cost_per_piece, manufacturing_type,
                notes, created_at, updated_at, created_by
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            data['product_name'],
            data.get('product_type_id'),
            'v1.0',
            grammage,
            data.get('pack_count', 1),
            data.get('status', 'draft'),
            round(total_cost, 4),
            data.get('manufacturing_type'),
            data.get('notes'),
            datetime.now().isoformat(),
            datetime.now().isoformat(),
            user_id
        ))
        
        formulation_id = cursor.lastrowid
        
        # Create initial version
        cursor.execute('''
            INSERT INTO formulation_versions (
                formulation_id, version_number, created_at, created_by,
                change_notes, ingredient_snapshot, cost_snapshot, grammage
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            formulation_id,
            'v1.0',
            datetime.now().isoformat(),
            user_id,
            'Initial version',
            json.dumps(ingredients),
            round(total_cost, 4),
            grammage
        ))
        
        version_id = cursor.lastrowid
        
        # Insert ingredients
        for idx, ing in enumerate(ingredients):
            cursor.execute('''
                INSERT INTO formulation_ingredients (
                    formulation_id, version_id, ingredient_id, percentage,
                    quantity_grams, cost_per_piece, display_order
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (
                formulation_id,
                version_id,
                ing['ingredient_id'],
                ing['percentage'],
                ing['quantity_grams'],
                ing['cost_per_piece'],
                idx
            ))
        
        # Add benefits
        for benefit_id in data.get('benefits', []):
            cursor.execute(
                'INSERT INTO formulation_benefits (formulation_id, benefit_id) VALUES (?, ?)',
                (formulation_id, benefit_id)
            )
        
        # Add tags
        for tag_id in data.get('tags', []):
            cursor.execute(
                'INSERT INTO formulation_tags (formulation_id, tag_id, tagged_by) VALUES (?, ?, ?)',
                (formulation_id, tag_id, user_id)
            )
        
        conn.commit()
        conn.close()
        
        return jsonify({
            'message': 'Formulation created successfully',
            'formulation_id': formulation_id,
            'total_cost': round(total_cost, 4)
        }), 201
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/formulations/<int:id>', methods=['PUT'])
@jwt_required()
def update_formulation(id):
    """Update formulation - creates new version if significant changes"""
    try:
        data = request.get_json()
        user_id = get_jwt_identity()
        
        conn = get_db()
        cursor = conn.cursor()
        
        # Check if exists
        cursor.execute('SELECT * FROM formulations WHERE id = ?', (id,))
        existing = cursor.fetchone()
        
        if not existing:
            conn.close()
            return jsonify({'error': 'Formulation not found'}), 404
        
        # Calculate if this is a significant change (new version needed)
        ingredients = data.get('ingredients', [])
        create_new_version = False
        
        if ingredients:
            # Check if ingredient list or percentages changed
            cursor.execute('''
                SELECT ingredient_id, percentage
                FROM formulation_ingredients
                WHERE formulation_id = ? AND version_id = (
                    SELECT id FROM formulation_versions
                    WHERE formulation_id = ?
                    ORDER BY created_at DESC LIMIT 1
                )
            ''', (id, id))
            
            old_ingredients = {row['ingredient_id']: row['percentage'] for row in cursor.fetchall()}
            new_ingredients = {ing['ingredient_id']: float(ing['percentage']) for ing in ingredients}
            
            if old_ingredients != new_ingredients:
                create_new_version = True
        
        # Calculate new cost
        total_cost = 0
        grammage = float(data.get('grammage', existing['grammage']))
        
        if ingredients:
            for ing in ingredients:
                cursor.execute(
                    'SELECT landed_cost_net_gst FROM ingredients WHERE id = ?',
                    (ing['ingredient_id'],)
                )
                ingredient = cursor.fetchone()
                if ingredient:
                    cost_per_kg = float(ingredient['landed_cost_net_gst'])
                    percentage = float(ing['percentage'])
                    quantity_kg = (grammage * percentage) / 100000
                    ing['cost_per_piece'] = quantity_kg * cost_per_kg
                    ing['quantity_grams'] = (grammage * percentage) / 100
                    total_cost += ing['cost_per_piece']
        
        # Update formulation
        new_version = existing['current_version']
        
        if create_new_version:
            # Increment version (v1.0 -> v1.1 or v1.9 -> v2.0)
            version_parts = existing['current_version'].replace('v', '').split('.')
            major = int(version_parts[0])
            minor = int(version_parts[1])
            
            minor += 1
            if minor >= 10:
                major += 1
                minor = 0
            
            new_version = f'v{major}.{minor}'
        
        cursor.execute('''
            UPDATE formulations SET
                product_name = ?, product_type_id = ?, current_version = ?,
                grammage = ?, pack_count = ?, status = ?,
                total_cost_per_piece = ?, manufacturing_type = ?,
                notes = ?, updated_at = ?
            WHERE id = ?
        ''', (
            data.get('product_name', existing['product_name']),
            data.get('product_type_id', existing['product_type_id']),
            new_version,
            grammage,
            data.get('pack_count', existing['pack_count']),
            data.get('status', existing['status']),
            round(total_cost, 4) if total_cost else existing['total_cost_per_piece'],
            data.get('manufacturing_type', existing['manufacturing_type']),
            data.get('notes', existing['notes']),
            datetime.now().isoformat(),
            id
        ))
        
        # Create new version if needed
        if create_new_version and ingredients:
            cursor.execute('''
                INSERT INTO formulation_versions (
                    formulation_id, version_number, created_at, created_by,
                    change_notes, ingredient_snapshot, cost_snapshot, grammage
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
            ''', (
                id,
                new_version,
                datetime.now().isoformat(),
                user_id,
                data.get('change_notes', 'Updated formulation'),
                json.dumps(ingredients),
                round(total_cost, 4),
                grammage
            ))
            
            version_id = cursor.lastrowid
            
            # Delete old ingredient links for current version and add new ones
            cursor.execute(
                'DELETE FROM formulation_ingredients WHERE formulation_id = ? AND version_id IS NULL',
                (id,)
            )
            
            for idx, ing in enumerate(ingredients):
                cursor.execute('''
                    INSERT INTO formulation_ingredients (
                        formulation_id, version_id, ingredient_id, percentage,
                        quantity_grams, cost_per_piece, display_order
                    ) VALUES (?, ?, ?, ?, ?, ?, ?)
                ''', (
                    id,
                    version_id,
                    ing['ingredient_id'],
                    ing['percentage'],
                    ing['quantity_grams'],
                    ing['cost_per_piece'],
                    idx
                ))
        
        # Update benefits
        if 'benefits' in data:
            cursor.execute('DELETE FROM formulation_benefits WHERE formulation_id = ?', (id,))
            for benefit_id in data['benefits']:
                cursor.execute(
                    'INSERT INTO formulation_benefits (formulation_id, benefit_id) VALUES (?, ?)',
                    (id, benefit_id)
                )
        
        # Update tags
        if 'tags' in data:
            cursor.execute('DELETE FROM formulation_tags WHERE formulation_id = ?', (id,))
            for tag_id in data['tags']:
                cursor.execute(
                    'INSERT INTO formulation_tags (formulation_id, tag_id, tagged_by) VALUES (?, ?, ?)',
                    (id, tag_id, user_id)
                )
        
        conn.commit()
        conn.close()
        
        return jsonify({
            'message': 'Formulation updated successfully',
            'new_version': new_version if create_new_version else None,
            'total_cost': round(total_cost, 4) if total_cost else None
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/formulations/<int:id>/duplicate', methods=['POST'])
@jwt_required()
def duplicate_formulation(id):
    """Duplicate an existing formulation"""
    try:
        data = request.get_json()
        user_id = get_jwt_identity()
        
        conn = get_db()
        cursor = conn.cursor()
        
        # Get original formulation
        cursor.execute('SELECT * FROM formulations WHERE id = ?', (id,))
        original = cursor.fetchone()
        
        if not original:
            conn.close()
            return jsonify({'error': 'Formulation not found'}), 404
        
        # Create new name
        new_name = data.get('new_name', f"{original['product_name']} (Copy)")
        
        # Check for duplicate name
        cursor.execute('SELECT id FROM formulations WHERE product_name = ?', (new_name,))
        if cursor.fetchone():
            conn.close()
            return jsonify({'error': 'Product name already exists'}), 400
        
        # Insert new formulation
        cursor.execute('''
            INSERT INTO formulations (
                product_name, product_type_id, current_version, grammage,
                pack_count, status, total_cost_per_piece, manufacturing_type,
                notes, created_at, updated_at, created_by
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            new_name,
            original['product_type_id'],
            'v1.0',
            original['grammage'],
            original['pack_count'],
            'draft',
            original['total_cost_per_piece'],
            original['manufacturing_type'],
            f"Duplicated from {original['product_name']}",
            datetime.now().isoformat(),
            datetime.now().isoformat(),
            user_id
        ))
        
        new_formulation_id = cursor.lastrowid
        
        # Get original ingredients
        cursor.execute('''
            SELECT * FROM formulation_ingredients
            WHERE formulation_id = ? AND version_id = (
                SELECT id FROM formulation_versions
                WHERE formulation_id = ?
                ORDER BY created_at DESC LIMIT 1
            )
        ''', (id, id))
        
        original_ingredients = [dict_from_row(row) for row in cursor.fetchall()]
        
        # Create initial version for duplicate
        cursor.execute('''
            INSERT INTO formulation_versions (
                formulation_id, version_number, created_at, created_by,
                change_notes, ingredient_snapshot, cost_snapshot, grammage
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            new_formulation_id,
            'v1.0',
            datetime.now().isoformat(),
            user_id,
            f'Duplicated from {original["product_name"]}',
            json.dumps(original_ingredients),
            original['total_cost_per_piece'],
            original['grammage']
        ))
        
        new_version_id = cursor.lastrowid
        
        # Copy ingredients
        for ing in original_ingredients:
            cursor.execute('''
                INSERT INTO formulation_ingredients (
                    formulation_id, version_id, ingredient_id, percentage,
                    quantity_grams, cost_per_piece, display_order
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (
                new_formulation_id,
                new_version_id,
                ing['ingredient_id'],
                ing['percentage'],
                ing['quantity_grams'],
                ing['cost_per_piece'],
                ing['display_order']
            ))
        
        # Copy benefits
        cursor.execute('''
            INSERT INTO formulation_benefits (formulation_id, benefit_id)
            SELECT ?, benefit_id FROM formulation_benefits WHERE formulation_id = ?
        ''', (new_formulation_id, id))
        
        # Copy tags
        cursor.execute('''
            INSERT INTO formulation_tags (formulation_id, tag_id, tagged_by)
            SELECT ?, tag_id, ? FROM formulation_tags WHERE formulation_id = ?
        ''', (new_formulation_id, user_id, id))
        
        conn.commit()
        conn.close()
        
        return jsonify({
            'message': 'Formulation duplicated successfully',
            'formulation_id': new_formulation_id
        }), 201
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/formulations/<int:id>', methods=['DELETE'])
@jwt_required()
def delete_formulation(id):
    """Delete formulation (admin only)"""
    try:
        conn = get_db()
        cursor = conn.cursor()
        
        # Check if exists
        cursor.execute('SELECT product_name FROM formulations WHERE id = ?', (id,))
        formulation = cursor.fetchone()
        
        if not formulation:
            conn.close()
            return jsonify({'error': 'Formulation not found'}), 404
        
        # Delete formulation (cascade will delete related records)
        cursor.execute('DELETE FROM formulations WHERE id = ?', (id,))
        
        conn.commit()
        conn.close()
        
        return jsonify({'message': 'Formulation deleted successfully'}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============================================================================
# VERSION CONTROL ENDPOINTS
# ============================================================================

@app.route('/api/formulations/<int:id>/versions', methods=['GET'])
@jwt_required()
def get_formulation_versions(id):
    """Get all versions of a formulation"""
    try:
        conn = get_db()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT fv.*, u.name as created_by_name
            FROM formulation_versions fv
            LEFT JOIN users u ON fv.created_by = u.id
            WHERE fv.formulation_id = ?
            ORDER BY fv.created_at DESC
        ''', (id,))
        
        versions = [dict_from_row(row) for row in cursor.fetchall()]
        
        # Parse ingredient snapshots
        for version in versions:
            if version.get('ingredient_snapshot'):
                version['ingredient_snapshot'] = json.loads(version['ingredient_snapshot'])
        
        conn.close()
        
        return jsonify({'versions': versions}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/formulations/<int:id>/versions/compare', methods=['GET'])
@jwt_required()
def compare_versions(id):
    """Compare two versions of a formulation"""
    try:
        v1 = request.args.get('v1')
        v2 = request.args.get('v2')
        
        if not v1 or not v2:
            return jsonify({'error': 'Both v1 and v2 parameters required'}), 400
        
        conn = get_db()
        cursor = conn.cursor()
        
        # Get version 1
        cursor.execute('''
            SELECT * FROM formulation_versions
            WHERE formulation_id = ? AND version_number = ?
        ''', (id, v1))
        
        version1 = cursor.fetchone()
        
        # Get version 2
        cursor.execute('''
            SELECT * FROM formulation_versions
            WHERE formulation_id = ? AND version_number = ?
        ''', (id, v2))
        
        version2 = cursor.fetchone()
        
        if not version1 or not version2:
            conn.close()
            return jsonify({'error': 'Version not found'}), 404
        
        v1_dict = dict_from_row(version1)
        v2_dict = dict_from_row(version2)
        
        # Parse snapshots
        v1_dict['ingredient_snapshot'] = json.loads(v1_dict['ingredient_snapshot']) if v1_dict.get('ingredient_snapshot') else []
        v2_dict['ingredient_snapshot'] = json.loads(v2_dict['ingredient_snapshot']) if v2_dict.get('ingredient_snapshot') else []
        
        # Calculate differences
        v1_ingredients = {ing['ingredient_id']: ing for ing in v1_dict['ingredient_snapshot']}
        v2_ingredients = {ing['ingredient_id']: ing for ing in v2_dict['ingredient_snapshot']}
        
        added = [ing_id for ing_id in v2_ingredients if ing_id not in v1_ingredients]
        removed = [ing_id for ing_id in v1_ingredients if ing_id not in v2_ingredients]
        modified = []
        
        for ing_id in v1_ingredients:
            if ing_id in v2_ingredients:
                if v1_ingredients[ing_id]['percentage'] != v2_ingredients[ing_id]['percentage']:
                    modified.append({
                        'ingredient_id': ing_id,
                        'old_percentage': v1_ingredients[ing_id]['percentage'],
                        'new_percentage': v2_ingredients[ing_id]['percentage']
                    })
        
        # Get ingredient names
        if added or removed or modified:
            ing_ids = list(set(added + removed + [m['ingredient_id'] for m in modified]))
            placeholders = ','.join('?' * len(ing_ids))
            cursor.execute(f'SELECT id, name FROM ingredients WHERE id IN ({placeholders})', ing_ids)
            ing_names = {row['id']: row['name'] for row in cursor.fetchall()}
        else:
            ing_names = {}
        
        conn.close()
        
        return jsonify({
            'version1': v1_dict,
            'version2': v2_dict,
            'differences': {
                'added': [{'ingredient_id': iid, 'name': ing_names.get(iid)} for iid in added],
                'removed': [{'ingredient_id': iid, 'name': ing_names.get(iid)} for iid in removed],
                'modified': [{**m, 'name': ing_names.get(m['ingredient_id'])} for m in modified],
                'cost_change': v2_dict['cost_snapshot'] - v1_dict['cost_snapshot']
            }
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/formulations/<int:id>/versions/<int:version_id>/restore', methods=['POST'])
@jwt_required()
def restore_version(id, version_id):
    """Restore a previous version (creates new version)"""
    try:
        user_id = get_jwt_identity()
        
        conn = get_db()
        cursor = conn.cursor()
        
        # Get the version to restore
        cursor.execute('''
            SELECT * FROM formulation_versions
            WHERE id = ? AND formulation_id = ?
        ''', (version_id, id))
        
        old_version = cursor.fetchone()
        
        if not old_version:
            conn.close()
            return jsonify({'error': 'Version not found'}), 404
        
        # Get current formulation
        cursor.execute('SELECT * FROM formulations WHERE id = ?', (id,))
        formulation = cursor.fetchone()
        
        # Increment version
        version_parts = formulation['current_version'].replace('v', '').split('.')
        major = int(version_parts[0])
        minor = int(version_parts[1]) + 1
        
        if minor >= 10:
            major += 1
            minor = 0
        
        new_version = f'v{major}.{minor}'
        
        # Create new version from old snapshot
        cursor.execute('''
            INSERT INTO formulation_versions (
                formulation_id, version_number, created_at, created_by,
                change_notes, ingredient_snapshot, cost_snapshot, grammage
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            id,
            new_version,
            datetime.now().isoformat(),
            user_id,
            f"Restored from {old_version['version_number']}",
            old_version['ingredient_snapshot'],
            old_version['cost_snapshot'],
            old_version['grammage']
        ))
        
        new_version_id = cursor.lastrowid
        
        # Parse ingredients from snapshot
        ingredients = json.loads(old_version['ingredient_snapshot'])
        
        # Insert ingredients
        for idx, ing in enumerate(ingredients):
            cursor.execute('''
                INSERT INTO formulation_ingredients (
                    formulation_id, version_id, ingredient_id, percentage,
                    quantity_grams, cost_per_piece, display_order
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
            ''', (
                id,
                new_version_id,
                ing['ingredient_id'],
                ing['percentage'],
                ing.get('quantity_grams'),
                ing.get('cost_per_piece'),
                idx
            ))
        
        # Update formulation
        cursor.execute('''
            UPDATE formulations SET
                current_version = ?,
                grammage = ?,
                total_cost_per_piece = ?,
                updated_at = ?
            WHERE id = ?
        ''', (
            new_version,
            old_version['grammage'],
            old_version['cost_snapshot'],
            datetime.now().isoformat(),
            id
        ))
        
        conn.commit()
        conn.close()
        
        return jsonify({
            'message': f'Restored to version {old_version["version_number"]} as {new_version}',
            'new_version': new_version
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============================================================================
# TEST RESULTS ENDPOINTS
# ============================================================================

@app.route('/api/formulations/<int:id>/tests', methods=['GET'])
@jwt_required()
def get_test_results(id):
    """Get all test results for a formulation"""
    try:
        conn = get_db()
        cursor = conn.cursor()
        
        cursor.execute('''
            SELECT tr.*, u.name as tested_by_name, fv.version_number
            FROM test_results tr
            LEFT JOIN users u ON tr.tested_by = u.id
            LEFT JOIN formulation_versions fv ON tr.version_id = fv.id
            WHERE tr.formulation_id = ?
            ORDER BY tr.test_date DESC
        ''', (id,))
        
        tests = [dict_from_row(row) for row in cursor.fetchall()]
        conn.close()
        
        return jsonify({'tests': tests}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/formulations/<int:id>/tests', methods=['POST'])
@jwt_required()
def create_test_result(id):
    """Add test result for a formulation"""
    try:
        data = request.get_json()
        user_id = get_jwt_identity()
        
        conn = get_db()
        cursor = conn.cursor()
        
        # Verify formulation exists
        cursor.execute('SELECT id FROM formulations WHERE id = ?', (id,))
        if not cursor.fetchone():
            conn.close()
            return jsonify({'error': 'Formulation not found'}), 404
        
        # Insert test result
        cursor.execute('''
            INSERT INTO test_results (
                formulation_id, version_id, test_date, tested_by,
                hardness_value, hardness_method,
                lather_quality, lather_quantity, lather_stability,
                notes, created_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        ''', (
            id,
            data.get('version_id'),
            data.get('test_date', datetime.now().date().isoformat()),
            user_id,
            data.get('hardness_value'),
            data.get('hardness_method'),
            data.get('lather_quality'),
            data.get('lather_quantity'),
            data.get('lather_stability'),
            data.get('notes'),
            datetime.now().isoformat()
        ))
        
        test_id = cursor.lastrowid
        
        conn.commit()
        conn.close()
        
        return jsonify({
            'message': 'Test result added successfully',
            'test_id': test_id
        }), 201
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/tests/<int:test_id>', methods=['PUT'])
@jwt_required()
def update_test_result(test_id):
    """Update test result"""
    try:
        data = request.get_json()
        
        conn = get_db()
        cursor = conn.cursor()
        
        # Check if exists
        cursor.execute('SELECT id FROM test_results WHERE id = ?', (test_id,))
        if not cursor.fetchone():
            conn.close()
            return jsonify({'error': 'Test result not found'}), 404
        
        # Update
        cursor.execute('''
            UPDATE test_results SET
                test_date = ?,
                hardness_value = ?,
                hardness_method = ?,
                lather_quality = ?,
                lather_quantity = ?,
                lather_stability = ?,
                notes = ?
            WHERE id = ?
        ''', (
            data.get('test_date'),
            data.get('hardness_value'),
            data.get('hardness_method'),
            data.get('lather_quality'),
            data.get('lather_quantity'),
            data.get('lather_stability'),
            data.get('notes'),
            test_id
        ))
        
        conn.commit()
        conn.close()
        
        return jsonify({'message': 'Test result updated successfully'}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/tests/<int:test_id>', methods=['DELETE'])
@jwt_required()
def delete_test_result(test_id):
    """Delete test result"""
    try:
        conn = get_db()
        cursor = conn.cursor()
        
        cursor.execute('DELETE FROM test_results WHERE id = ?', (test_id,))
        
        if cursor.rowcount == 0:
            conn.close()
            return jsonify({'error': 'Test result not found'}), 404
        
        conn.commit()
        conn.close()
        
        return jsonify({'message': 'Test result deleted successfully'}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============================================================================
# BOM GENERATION ENDPOINT
# ============================================================================

@app.route('/api/formulations/<int:id>/bom/generate', methods=['POST'])
@jwt_required()
def generate_bom(id):
    """Generate Bill of Materials with wastage calculation"""
    try:
        data = request.get_json()
        
        target_quantity = int(data.get('quantity', 1000))  # pieces
        pack_count = int(data.get('pack_count', 1))
        wastage_percent = float(data.get('wastage_percent', 2.0))
        
        conn = get_db()
        cursor = conn.cursor()
        
        # Get formulation
        cursor.execute('''
            SELECT f.*, fv.version_number
            FROM formulations f
            LEFT JOIN formulation_versions fv ON f.id = fv.formulation_id
            WHERE f.id = ?
            ORDER BY fv.created_at DESC
            LIMIT 1
        ''', (id,))
        
        formulation = cursor.fetchone()
        
        if not formulation:
            conn.close()
            return jsonify({'error': 'Formulation not found'}), 404
        
        # Get ingredients
        cursor.execute('''
            SELECT fi.*, i.name as ingredient_name, i.landed_cost_net_gst,
                   c.name as category_name
            FROM formulation_ingredients fi
            JOIN ingredients i ON fi.ingredient_id = i.id
            LEFT JOIN categories c ON i.category_id = c.id
            WHERE fi.formulation_id = ?
            ORDER BY fi.display_order
        ''', (id,))
        
        ingredients = [dict_from_row(row) for row in cursor.fetchall()]
        conn.close()
        
        # Calculate BOM
        grammage = float(formulation['grammage'])
        total_pieces = target_quantity * pack_count
        
        bom_items = []
        total_cost = 0
        
        for ing in ingredients:
            # Per piece calculation
            per_piece_grams = float(ing['quantity_grams'])
            
            # Total needed
            total_grams = per_piece_grams * total_pieces
            total_kg = total_grams / 1000
            
            # With wastage
            wastage_kg = total_kg * (wastage_percent / 100)
            order_qty_kg = total_kg + wastage_kg
            
            # Cost
            cost_per_kg = float(ing['landed_cost_net_gst'])
            line_cost = order_qty_kg * cost_per_kg
            total_cost += line_cost
            
            bom_items.append({
                'ingredient_id': ing['ingredient_id'],
                'ingredient_name': ing['ingredient_name'],
                'category': ing['category_name'],
                'percentage': float(ing['percentage']),
                'per_piece_grams': round(per_piece_grams, 2),
                'total_kg': round(total_kg, 3),
                'wastage_kg': round(wastage_kg, 3),
                'order_qty_kg': round(order_qty_kg, 3),
                'cost_per_kg': round(cost_per_kg, 2),
                'line_cost': round(line_cost, 2)
            })
        
        # Summary
        total_weight_kg = sum(item['total_kg'] for item in bom_items)
        total_wastage_kg = sum(item['wastage_kg'] for item in bom_items)
        total_order_kg = sum(item['order_qty_kg'] for item in bom_items)
        
        cost_per_piece = total_cost / total_pieces
        cost_per_pack = cost_per_piece * pack_count
        
        result = {
            'formulation': {
                'id': formulation['id'],
                'product_name': formulation['product_name'],
                'version': formulation['current_version'],
                'grammage': grammage
            },
            'parameters': {
                'target_quantity': target_quantity,
                'pack_count': pack_count,
                'total_pieces': total_pieces,
                'wastage_percent': wastage_percent
            },
            'items': bom_items,
            'summary': {
                'total_weight_kg': round(total_weight_kg, 3),
                'total_wastage_kg': round(total_wastage_kg, 3),
                'total_order_kg': round(total_order_kg, 3),
                'total_cost': round(total_cost, 2),
                'cost_per_piece': round(cost_per_piece, 4),
                'cost_per_pack': round(cost_per_pack, 2)
            },
            'generated_at': datetime.now().isoformat()
        }
        
        return jsonify(result), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============================================================================
# ADVANCED SEARCH ENDPOINTS
# ============================================================================

@app.route('/api/search/ingredients', methods=['POST'])
@jwt_required()
def search_ingredients():
    """Advanced multi-criteria ingredient search"""
    try:
        data = request.get_json()
        
        conn = get_db()
        cursor = conn.cursor()
        
        query = '''
            SELECT i.*, c.name as category_name, sc.name as subcategory_name,
                   s.name as supplier_name
            FROM ingredients i
            LEFT JOIN categories c ON i.category_id = c.id
            LEFT JOIN subcategories sc ON i.subcategory_id = sc.id
            LEFT JOIN suppliers s ON i.supplier_id = s.id
            WHERE 1=1
        '''
        params = []
        
        # Text search
        if data.get('search'):
            query += ' AND (i.name LIKE ? OR i.inci_name LIKE ? OR i.cas_number LIKE ?)'
            search_term = f"%{data['search']}%"
            params.extend([search_term, search_term, search_term])
        
        # Categories (multi-select)
        if data.get('categories'):
            placeholders = ','.join('?' * len(data['categories']))
            query += f' AND i.category_id IN ({placeholders})'
            params.extend(data['categories'])
        
        # Cost range
        if data.get('cost_min') is not None:
            query += ' AND i.landed_cost_net_gst >= ?'
            params.append(data['cost_min'])
        
        if data.get('cost_max') is not None:
            query += ' AND i.landed_cost_net_gst <= ?'
            params.append(data['cost_max'])
        
        # Stock status
        if data.get('stock_status'):
            query += ' AND i.stock_status = ?'
            params.append(data['stock_status'])
        
        # Tags
        if data.get('tags'):
            placeholders = ','.join('?' * len(data['tags']))
            query += f''' AND i.id IN (
                SELECT ingredient_id FROM ingredient_tags
                WHERE tag IN ({placeholders})
            )'''
            params.extend(data['tags'])
        
        # Supplier
        if data.get('supplier_id'):
            query += ' AND i.supplier_id = ?'
            params.append(data['supplier_id'])
        
        query += ' ORDER BY i.name'
        
        cursor.execute(query, params)
        results = [dict_from_row(row) for row in cursor.fetchall()]
        conn.close()
        
        return jsonify({
            'results': results,
            'count': len(results)
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/search/formulations', methods=['POST'])
@jwt_required()
def search_formulations():
    """Advanced multi-criteria formulation search"""
    try:
        data = request.get_json()
        
        conn = get_db()
        cursor = conn.cursor()
        
        query = '''
            SELECT DISTINCT f.*, pt.name as product_type_name,
                   COUNT(DISTINCT fi.ingredient_id) as ingredient_count
            FROM formulations f
            LEFT JOIN product_types pt ON f.product_type_id = pt.id
            LEFT JOIN formulation_ingredients fi ON f.id = fi.formulation_id
            WHERE 1=1
        '''
        params = []
        
        # Text search
        if data.get('search'):
            query += ' AND f.product_name LIKE ?'
            params.append(f"%{data['search']}%")
        
        # Product types
        if data.get('product_types'):
            placeholders = ','.join('?' * len(data['product_types']))
            query += f' AND f.product_type_id IN ({placeholders})'
            params.extend(data['product_types'])
        
        # Status
        if data.get('statuses'):
            placeholders = ','.join('?' * len(data['statuses']))
            query += f' AND f.status IN ({placeholders})'
            params.extend(data['statuses'])
        
        # Cost range
        if data.get('cost_min') is not None:
            query += ' AND f.total_cost_per_piece >= ?'
            params.append(data['cost_min'])
        
        if data.get('cost_max') is not None:
            query += ' AND f.total_cost_per_piece <= ?'
            params.append(data['cost_max'])
        
        # Date range
        if data.get('created_after'):
            query += ' AND f.created_at >= ?'
            params.append(data['created_after'])
        
        if data.get('created_before'):
            query += ' AND f.created_at <= ?'
            params.append(data['created_before'])
        
        # Benefits
        if data.get('benefits'):
            placeholders = ','.join('?' * len(data['benefits']))
            query += f''' AND f.id IN (
                SELECT formulation_id FROM formulation_benefits
                WHERE benefit_id IN ({placeholders})
            )'''
            params.extend(data['benefits'])
        
        # Has test results
        if data.get('has_tests') is not None:
            if data['has_tests']:
                query += ' AND EXISTS (SELECT 1 FROM test_results WHERE formulation_id = f.id)'
            else:
                query += ' AND NOT EXISTS (SELECT 1 FROM test_results WHERE formulation_id = f.id)'
        
        query += ' GROUP BY f.id ORDER BY f.created_at DESC'
        
        cursor.execute(query, params)
        results = [dict_from_row(row) for row in cursor.fetchall()]
        conn.close()
        
        return jsonify({
            'results': results,
            'count': len(results)
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============================================================================
# REFERENCE DATA ENDPOINTS
# ============================================================================

@app.route('/api/product-types', methods=['GET'])
@jwt_required()
def get_product_types():
    """Get all product types"""
    try:
        conn = get_db()
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM product_types ORDER BY name')
        types = [dict_from_row(row) for row in cursor.fetchall()]
        conn.close()
        
        return jsonify({'product_types': types}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/benefits', methods=['GET'])
@jwt_required()
def get_benefits():
    """Get all benefit categories"""
    try:
        conn = get_db()
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM benefit_categories ORDER BY display_order, name')
        benefits = [dict_from_row(row) for row in cursor.fetchall()]
        conn.close()
        
        return jsonify({'benefits': benefits}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/suppliers', methods=['GET'])
@jwt_required()
def get_suppliers():
    """Get all suppliers"""
    try:
        conn = get_db()
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM suppliers WHERE is_active = 1 ORDER BY name')
        suppliers = [dict_from_row(row) for row in cursor.fetchall()]
        conn.close()
        
        return jsonify({'suppliers': suppliers}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/api/tags', methods=['GET'])
@jwt_required()
def get_tags():
    """Get all tags"""
    try:
        conn = get_db()
        cursor = conn.cursor()
        
        cursor.execute('SELECT * FROM tags ORDER BY name')
        tags = [dict_from_row(row) for row in cursor.fetchall()]
        conn.close()
        
        return jsonify({'tags': tags}), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============================================================================
# DASHBOARD / STATISTICS ENDPOINTS
# ============================================================================

@app.route('/api/stats/dashboard', methods=['GET'])
@jwt_required()
def get_dashboard_stats():
    """Get dashboard statistics"""
    try:
        conn = get_db()
        cursor = conn.cursor()
        
        # Total counts
        cursor.execute('SELECT COUNT(*) as count FROM formulations')
        total_formulations = cursor.fetchone()['count']
        
        cursor.execute('SELECT COUNT(*) as count FROM ingredients')
        total_ingredients = cursor.fetchone()['count']
        
        cursor.execute('SELECT COUNT(*) as count FROM formulations WHERE status = "active"')
        active_formulations = cursor.fetchone()['count']
        
        cursor.execute('SELECT COUNT(*) as count FROM formulations WHERE status = "draft"')
        draft_formulations = cursor.fetchone()['count']
        
        # Recent formulations
        cursor.execute('''
            SELECT f.*, pt.name as product_type_name
            FROM formulations f
            LEFT JOIN product_types pt ON f.product_type_id = pt.id
            ORDER BY f.created_at DESC
            LIMIT 5
        ''')
        recent_formulations = [dict_from_row(row) for row in cursor.fetchall()]
        
        # Category breakdown
        cursor.execute('''
            SELECT c.name, COUNT(i.id) as count
            FROM categories c
            LEFT JOIN ingredients i ON c.id = i.category_id
            GROUP BY c.id, c.name
            ORDER BY count DESC
        ''')
        category_breakdown = [dict_from_row(row) for row in cursor.fetchall()]
        
        conn.close()
        
        return jsonify({
            'totals': {
                'formulations': total_formulations,
                'ingredients': total_ingredients,
                'active_formulations': active_formulations,
                'draft_formulations': draft_formulations
            },
            'recent_formulations': recent_formulations,
            'category_breakdown': category_breakdown
        }), 200
        
    except Exception as e:
        return jsonify({'error': str(e)}), 500

# ============================================================================
# HEALTH CHECK
# ============================================================================

@app.route('/api/health', methods=['GET'])
def health_check():
    """Health check endpoint"""
    return jsonify({
        'status': 'healthy',
        'timestamp': datetime.now().isoformat()
    }), 200

@app.route('/api/', methods=['GET'])
def api_root():
    """API root"""
    return jsonify({
        'message': 'Swati Soaps Formulation Management System API',
        'version': '2.0',
        'status': 'running'
    }), 200

# ============================================================================
# RUN APPLICATION
# ============================================================================

if __name__ == '__main__':
    # Check if database exists
    if not os.path.exists(app.config['DATABASE']):
        print("⚠️  WARNING: Database file not found!")
        print(f"   Expected location: {app.config['DATABASE']}")
        print("   Run initialize_database.py to create the database.")
    else:
        print(f"✅ Database found: {app.config['DATABASE']}")
    
    print("\n" + "="*70)
    print("  SWATI SOAPS FORMULATION MANAGEMENT SYSTEM")
    print("  Backend API Server v2.0")
    print("="*70)
    print(f"\n🚀 Starting server on http://localhost:5000")
    print(f"📊 API endpoints available at http://localhost:5000/api/")
    print(f"🔒 CORS enabled for: http://localhost:3000")
    print(f"\n💡 Press Ctrl+C to stop the server\n")
    
    app.run(debug=True, host='0.0.0.0', port=5000)
